import { Component } from '@angular/core';

@Component({
  selector: 'app-compound-details',
  templateUrl: './compound-details.component.html',
  styleUrls: ['./compound-details.component.css']
})
export class CompoundDetailsComponent {

}
