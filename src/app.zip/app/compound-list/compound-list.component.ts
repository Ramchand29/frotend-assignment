import { Component } from '@angular/core';
import {PageEvent} from '@angular/material/paginator';
import {MatDialog, MatDialogRef} from '@angular/material/dialog';
import { CreateComponent } from '../dialog/create/create.component';
import { DeleteComponent } from '../dialog/delete/delete.component';
import { UpdateComponent } from '../dialog/update/update.component';

@Component({
  selector: 'app-compound-list',
  templateUrl: './compound-list.component.html',
  styleUrls: ['./compound-list.component.css']
})
export class CompoundListComponent {

  object=[
    {
      id:1,
      name:"Shiba Inu",
      url:"https://material.angular.io/assets/img/examples/shiba2.jpg"
    },
    {id:2,
      name:"Shiba Inu",
      url:"https://material.angular.io/assets/img/examples/shiba2.jpg"
    },
    {id:3,
      name:"Shiba Inu",
      url:"https://material.angular.io/assets/img/examples/shiba2.jpg"
    },
    {id:4,
      name:"Shiba Inu",
      url:"https://material.angular.io/assets/img/examples/shiba2.jpg"
    }
]
  length = 200;
  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25];

  hidePageSize = false;
  showPageSizeOptions = true;
  showFirstLastButtons = true;
  disabled = false;

  pageEvent!: PageEvent;

  constructor(public dialog: MatDialog) {}

  update(e:any,datas:any): void {
    this.dialog.open(UpdateComponent, {
      width: '250px',
      data:datas
    });
    
    e.stopPropagation();
  }

  delete(e:any,datas:any): void {
    this.dialog.open(DeleteComponent, {
      width: '300px',
      data:datas
    });
    e.stopPropagation();
  }

  handlePageEvent(e: PageEvent) {
    this.pageEvent = e;
    this.length = e.length;
    this.pageSize = e.pageSize;
    this.pageIndex = e.pageIndex;
  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
}
