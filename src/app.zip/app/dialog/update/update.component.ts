import { Component, Inject ,OnInit} from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { MatDialogRef ,MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit{
  CompoundForm!:FormGroup;
  constructor(private formBuilder:FormBuilder,@Inject(MAT_DIALOG_DATA) public editdata:any,public dialogRef: MatDialogRef<UpdateComponent>){

  }
  ngOnInit(){
    this.CompoundForm = this.formBuilder.group({
      compoundName : ['',Validators.required],
      compoundDes : ['',Validators.required]
    })
    console.log(this.editdata);
  }


  updateCompund(){
    console.log(this.CompoundForm.value);
    
  }
}
